// app.js
App({
  onLaunch() {
    // 展示本地存储能力
    const logs = wx.getStorageSync('logs') || []
    logs.unshift(Date.now())
    wx.setStorageSync('logs', logs)

    // 登录
    wx.login({
      success: res => {
        // 发送 res.code 到后台换取 openId, sessionKey, unionId
      }
    })
  },
  //定义全局数据，传递游戏人数，筹码等参数
  globalData: {
    userInfo: null,
    local_player_num:2,
    local_player_money:1000,
    local_game_rounds:3,
    AI_difficuty:1
  }
})
